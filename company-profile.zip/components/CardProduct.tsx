"use client";
import { useEffect, useRef } from "react";
import { renderCards } from "@/script/script";

export default function CardProduct() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (ref.current) renderCards(ref.current);
  }, []);

  return <div ref={ref} className="card-product" />;
}