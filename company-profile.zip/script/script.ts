import data from "../data/data.json";

export interface Product {
  id: string;
  name: string;
  brand: string;
  from: string;
  category: string;
  cat2: string;
  permasalahan: string[];
  image: string;
}

const DEFAULT_IMAGE = "default.webp"; // taruh di public/images/
const CARD_WIDTH = 280;

// Ambil semua data
export function getProducts(): Product[] {
  return data as Product[];
}

// Ambil 1 data berdasarkan id
export function getProductById(id: string): Product | undefined {
  return getProducts().find((p) => p.id === id);
}

// Filter berdasarkan kategori (opsional)
export function getProductsByCategory(category: string): Product[] {
  return getProducts().filter((p) => p.category === category);
}

// Versi DOM manual (mirip kode kamu sebelumnya)
export function renderCards(target: HTMLElement, products: Product[] = getProducts()) {
  target.innerHTML = "";

  products.forEach((p) => {
    const imageFile = p.image || DEFAULT_IMAGE;

    const card = document.createElement("div");
    card.className = "card";
    card.style.width = CARD_WIDTH + "px";

    card.innerHTML = `
      <img src="/${imageFile}" class="card-img-top" alt="${p.name}">
      <div class="card-body">
        <h4 class="card-title">${p.name}</h4>
        <p class="card-text">${p.brand} • ${p.from}</p>
        <p class="card-loc">${p.category} / ${p.cat2}</p>
      </div>
    `;

    target.appendChild(card);
  });
}