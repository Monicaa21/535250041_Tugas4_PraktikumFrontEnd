"use client"
import Carousel from 'react-bootstrap/Carousel';

interface Slide {
    title: string;
    subtitle: string;
    imageUrl: string;
}

const HeroSection = () => {
    const slides: Slide[] = [
        {
            title: "First slide label",
            subtitle: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Esse, nisi.",
            imageUrl: "/hero-section/face_concern.jpeg",
        },
        {
            title: "Second slide label",
            subtitle: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nostrum!",
            imageUrl: "/hero-section/body_concern.jpeg",
        },
        {
            title: "Third slide label",
            subtitle: "Lorem ipsum dolor sit, amet consectetur adipisicing elit.",
            imageUrl: "/hero-section/hair_scalp.jpeg",
        }
    ]

    return (
        <Carousel fade interval={ 4000 } data-bs-theme="dark" className="hero-carousel">
            { slides.map((slide, index) => (
                <Carousel.Item key={ index }>
                    <div
                        style={{
                            backgroundImage:`url(${ slide.imageUrl})`,
                            backgroundSize:"cover",
                            backgroundPosition:"center",
                            height:"60vh",
                        }}>
                    </div>
                    <Carousel.Caption className="hero-caption">
                        <h2 className="display-4 fw-bold">{ slide.title }</h2>
                        <p className="lead">{ slide.subtitle }</p>
                    </Carousel.Caption>
                </Carousel.Item>
            )
            )}
        </Carousel>
    )
}

export default HeroSection;