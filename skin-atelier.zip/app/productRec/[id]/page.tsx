import { getProductById } from "../../../script/script";

export default async function ProductDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const product = getProductById(id);

  if (!product) return <p>Produk tidak ditemukan</p>;

  return (
    <div>
      <h1>{product.name}</h1>
      
      <p>{product.brand} | {product.from}</p>
    </div>
  );
}